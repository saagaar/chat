<?php 

class Searchjob extends Users_Controller 
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->data['active_side'] = 'searchajob';
		$this->renderTemplate('searchajob', $this->data);
	}
}