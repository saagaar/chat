<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

	public function index()	{
		echo 'here';
	}

}

/* End of file Client.php */
/* Location: ./application/controllers/Client.php */