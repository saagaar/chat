<?php 

class Job extends User_Controller 
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->data['active_side'] = 'job';
		$this->renderTemplate('myjobtasks', $this->data);
	}

	
}
