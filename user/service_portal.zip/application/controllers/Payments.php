<?php 

class Payments extends User_Controller 
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->data['active_side'] = 'payments';
		$this->renderTemplate('mypayments', $this->data);
	}
}
