
<div class="rightSection">
  <!-- Header -->
  
  <div class="col-md-12 col-sm-12 col-xs-12 pull-left no-padding hederLogoSec">
    <div class="header-bottom-user">
      <div class="wrapper">
        <div class="container">
          <div class="row" >
            <div class="col-lg-3 col-md-3 col-sm-12">
             
            </div>
            <div class="col-lg-9 col-md-9 col-sm-12">
              <div class="nav" id="nav">
                <a href="index.html#" id="toggle">
                  <i class="fa fa-bars">
                  </i>
                </a>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- /Header -->
  <!-- Center -->
  <!-- Center -->
  <div role="tabpanel" class="tab-pane " id="MyPaymentsArea">
    <div class="border-box"  style="margin-top: 2px;">
      <div  class=" custom-page-content">
       
      </div>
      <!--  My Payments table -->
      <div class="main-content">
        <div class="tab-section">
          <div class="row" style="background: #eeeeee;">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab-container" style="margin-top: 0px;">
              <div class=" bhoechie-tab">
                <div class="bhoechie-tab-content">
                  <div>

                    <nav class="navbar navbar-default new-opp-top-nav nc-menu">
                      <div class="container top-menu-container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-3" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-3">
                          <ul class="nav navbar-nav">
                            <li class="active" role="presentation">
                                <a href="index.html#MyPaymentsAreaSettings" MyContractsAreaCurrentContracts-controls="MyPaymentsAreaSettings" role="tab" data-toggle="tab">
                                  <i class="fa fa-university"></i> On&nbsp;Milestone
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="index.html#MyPaymentsAreaOurFollower" MyContractsAreaCurrentContracts-controls="MyPaymentsAreaOurFollower" role="tab" data-toggle="tab">
                                   <i class="fa fa-exchange"></i> Release&nbsp;Request  
                                </a>
                            </li>
                            <li role="presentation">
                                <a  href="index.html#MyPaymentsAreaAboutUs" MyContractsAreaCurrentContracts-controls="MyPaymentsAreaAboutUs" role="tab" data-toggle="tab">
                                 <i class="fa fa-undo"></i> Refund&nbsp;Request
                                </a>
                            </li>
                            <li role="presentation">
                                <a style="" href="index.html#MyPaymentsAreaOurTeam"  MyContractsAreaCurrentContracts-controls="MyPaymentsAreaOurTeam" role="tab" data-toggle="tab">
                                 <i style="padding: 5px 8px;" class="fa fa-eur"></i> My&nbsp;Payouts 
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="index.html#MyPaymentsAreaMyPay" MyContractsAreaCurrentContracts-controls="MyPaymentsAreaMyPay" role="tab" data-toggle="tab">
                                 <i class="fa fa-file-text-o"></i> My&nbsp;Invoice 
                                </a>
                            </li>
                          </ul>
                        </div><!-- /.navbar-collapse -->

                      </div><!-- /.container-fluid -->
                    </nav>

                    <div class="tab-content">
                      <div role="tabpanel" class="tab-pane active m-t-35" id="MyPaymentsAreaSettings" style="background: #eeeeee;margin-top:50px;">
                        <div class="pdng10-0 searchBar" style="border-bottom: 1px solid #eeeeee;">
                          <div class="col-md-12">
                            

                            <div class="col-lg-3" style=" margin-top: 12px;">
                              
                              <div class="pamentstats" style="  background-color: white; border-top: 5px solid green;">
                                <h2 class="text-center2 paymenfont2">Total Open Jobs</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">10</h2>
                              </div>

                            </div>
                            <div class="col-lg-3" style="margin-top: 12px;">
                              
                              <div class="pamentstats" style="  background-color: white; border-top: 5px solid green;">
                                <h2 class="text-center2 paymenfont2">Total Released</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">1000.€</h2>

                              </div>
                            </div>
                            <div class="col-lg-3" style="margin-top: 12px;">
                              
                              <div class="pamentstats" style="  background-color: white;border-top: 5px solid green;">
                                <h2 class="text-center2 paymenfont2">Total Refund</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">1000.€</h2>
                              </div>
                            </div>
                            <div class="col-lg-3" style="margin-top: 12px;">
                              
                              <div class="pamentstats" style="  background-color: white; white;border-top: 5px solid green;">
                                <h2 class="text-center2 paymenfont2">On Milestone</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">5000.€</h2>
                              </div>
                            </div>

                          </div>
                        </div>
                        <!--second section-->
                        <div class="vd_content-section clearfix"  style="margin-top: -11px; border-top: 1px solid #eeeeee;">
                          <div class="row">
                            <div class="col-md-12" style="margin-top: 26px;">
                              <div class="tab-content no-bd mrgn0 pdng0">
                                <div class="tab-pane active fade in" id="category1">
                                  <div class="panel widget container-fluid" style="background: #eee;">
                                    <div class="row mrgn30-0 projectRow" style=" background: #eeeeee;">
                                      <div class="">
                                        <div class="row" style=" margin-top: -34px;">
                                          <div class="col-md-12" style="margin-top: 26px;">
                                            <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0; border-bottom: 1px solid #eeeeee;"">
                                              <form>
                                                <div class="col-md-2 col-md-offset-2">

                                                </div>
                                                <div class="col-md-2">
                                                  <div>
                                                    <select>
                                                      <option value="" disabled="" selected="">Status
                                                      </option>
                                                      <option value="1">On Hold
                                                      </option>
                                                      <option value="2">Denied
                                                      </option>
                                                      <option value="3">Blocked
                                                      </option>
                                                      <option value="4">Removed
                                                      </option>
                                                    </select>
                                                  </div>                                                               </select>

                                                </div>
                                                <div class="col-md-2">
                                                  <div>
                                                    <select>
                                                      <option value="" disabled="" selected="">Status
                                                      </option>
                                                      <option value="1">On Hold
                                                      </option>
                                                      <option value="2">Denied
                                                      </option>
                                                      <option value="3">Blocked
                                                      </option>
                                                      <option value="4">Removed
                                                      </option>
                                                    </select>
                                                  </div>
                                                </div>

                                                <div class="col-md-2">
                                                  <input class="searchbox-ov" type="search" placeholder="Search">

                                                </div>
                                              </form>
                                            </div>  

                                            <div class="table-responsive">
                                              <!-- view on milestone table -->
                                              <table id="mytable" class="table table-bordred table-striped payment-milestone">
                                                <thead>
                                                  <th>
                                                    <input type="checkbox" id="checkall" />
                                                  </th>
                                                  <th>No </th>
                                                  <th>Date</th>
                                                  <th>Service type</th>
                                                  <th>Title</th>
                                                  <th>Amount Total</th>
                                                  <th>Payment Fee</th>
                                                  <th>Portal Fee</th>
                                                  <th>Payouts</th>
                                                  <th>Option</th>
                                                </thead>
                                                <tbody>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>01
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>Job
                                                    </td>
                                                    <td>Repaire mobile
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td class="options">
                                                      <p data-placement="top" data-toggle="tooltip" title="View">
                                                        <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewPaymentMilestoneModal" >
                                                          <span class="fa fa-eye">
                                                          </span>
                                                        </button>
                                                      </p>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>02
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>Job
                                                    </td>
                                                    <td>Repaire mobile
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td class="options">
                                                      <p data-placement="top" data-toggle="tooltip" title="View">
                                                        <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewPaymentMilestoneModal" >
                                                          <span class="fa fa-eye">
                                                          </span>
                                                        </button>
                                                      </p>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>03
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>Job
                                                    </td>
                                                    <td>Repaire mobile
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td class="options">
                                                      <p data-placement="top" data-toggle="tooltip" title="View">
                                                        <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewPaymentMilestoneModal" >
                                                          <span class="fa fa-eye">
                                                          </span>
                                                        </button>
                                                      </p>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>04
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>Job
                                                    </td>
                                                    <td>Repaire mobile
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td class="options">
                                                      <p data-placement="top" data-toggle="tooltip" title="View">
                                                        <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewPaymentMilestoneModal" >
                                                          <span class="fa fa-eye">
                                                          </span>
                                                        </button>
                                                      </p>
                                                    </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>05
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>Job
                                                    </td>
                                                    <td>Repaire mobile
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>1000,-€
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td>100,00 €
                                                    </td>
                                                    <td class="options">
                                                      <p data-placement="top" data-toggle="tooltip" title="View">
                                                        <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewPaymentMilestoneModal" >
                                                          <span class="fa fa-eye">
                                                          </span>
                                                        </button>
                                                      </p>
                                                    </td>
                                                  </tr>

                                                </tbody>
                                              </table>
                                              <div class="clearfix">
                                              </div>
                                              <ul class="pagination pull-right">
                                                <li class="disabled">
                                                  <a href="#">
                                                    <span class="glyphicon glyphicon-chevron-left">
                                                    </span>
                                                  </a>
                                                </li>
                                                <li class="active">
                                                  <a href="#">1
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">2
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">3
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">4
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">5
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="glyphicon glyphicon-chevron-right">
                                                    </span>
                                                  </a>
                                                </li>
                                              </ul>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                        <div class="modal-dialog">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                </span>
                                              </button>
                                              <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
                                              </h4>
                                            </div>
                                            <div class="modal-body">
                                              <div class="form-group">
                                                <input class="form-control " type="text" placeholder="Mohsin">
                                              </div>
                                              <div class="form-group">
                                                <input class="form-control " type="text" placeholder="Irshad">
                                              </div>
                                              <div class="form-group">
                                                <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
                                                </textarea>
                                              </div>
                                            </div>
                                            <div class="modal-footer ">
                                              <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
                                                <span class="glyphicon glyphicon-ok-sign">
                                                </span> Update
                                              </button>
                                            </div>
                                          </div>
                                          <!-- /.modal-content --> 
                                        </div>
                                        <!-- /.modal-dialog --> 
                                      </div>
                                      <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                        <div class="modal-dialog">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                </span>
                                              </button>
                                              <h4 class="modal-title custom_align" id="Heading">Delete this entry
                                              </h4>
                                            </div>
                                            <div class="modal-body">
                                              <div class="alert alert-danger">
                                                <span class="glyphicon glyphicon-warning-sign">
                                                </span> Are you sure you want to delete this Record?
                                              </div>
                                            </div>
                                            <div class="modal-footer ">
                                              <button type="button" class="btn btn-success" >
                                                <span class="glyphicon glyphicon-ok-sign">
                                                </span> Yes
                                              </button>
                                              <button type="button" class="btn btn-default" data-dismiss="modal">
                                                <span class="glyphicon glyphicon-remove">
                                                </span> No
                                              </button>
                                            </div>
                                          </div>
                                          <!-- /.modal-content --> 
                                        </div>
                                        <!-- /.modal-dialog --> 
                                      </div>

                                    </div>
                                  </div>
                                </div>
                                <!--tab-pane end -->
                              </div>
                              <!-- tab-content end -->
                            </div>
                            <!-- Projects List col-md-10 end -->
                          </div>
                          <!-- row end -->
                        </div>
                        <div class="clearfix">
                        </div>
                        <br>
                      </div>
                      <div role="tabpanel" class="tab-pane m-t-35" id="MyPaymentsAreaOurFollower" style="background: #eeeeee;margin-top:50px;">
                        <div class="row pdng10-0 searchBar" style="border-bottom: 1px solid #eeeeee;">
                          <div class="col-md-12">

                            <div class="col-lg-4" style="    margin-top: 12px;" >
                              <div class="pamentstats" style="  background-color: white;">
                                <h2 class="text-center2 paymenfont2">New Release Request</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">10</h2>
                              </div>

                            </div>
                            <div class="col-lg-4" style="    margin-top: 12px;">
                              <div class="pamentstats" style="  background-color: white;">
                                <h2 class="text-center2 paymenfont2">Accepted Release Request</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">5</h2>

                              </div>
                            </div>
                            <div class="col-lg-4" style="    margin-top: 12px;">
                              <div class="pamentstats" style="  background-color: white;">
                                <h2 class="text-center2 paymenfont2">Denied Release Request</h2>
                                <hr class="pauruler2">
                                <h2 class="text-center2">5</h2>
                              </div>
                            </div>

                          </div>
                        </div>
                        <!--second section-->
                        <div class="vd_content-section clearfix"  style="margin-top: -11px; border-top: 1px solid #eeeeee;">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="tab-content no-bd mrgn0 pdng0">
                                <div class="tab-pane active fade in" id="category1">
                                  <div class="panel widget container-fluid" style="background: #eee;">
                                    <div class="row mrgn30-0 projectRow" style=" background: #eeeeee;">
                                      <div class="container">
                                        <div class="row">
                                          <div class="col-md-12" style="margin-top: 26px;">
                                            <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0; border-bottom: 1px solid #eeeeee;"">
                                              <form>
                                                <div class="col-md-2 col-md-offset-2">

                                                </div>
                                                <div class="col-md-2">
                                                  <div>
                                                    <select>
                                                      <option value="" disabled="" selected="">Status
                                                      </option>
                                                      <option value="1">On Hold
                                                      </option>
                                                      <option value="2">Denied
                                                      </option>
                                                      <option value="3">Blocked
                                                      </option>
                                                      <option value="4">Removed
                                                      </option>
                                                    </select>
                                                  </div>                                                               
                                                </div>
                                                <div class="col-md-2">
                                                  <div>
                                                    <select>
                                                      <option value="" disabled="" selected="">Status
                                                      </option>
                                                      <option value="1">On Hold
                                                      </option>
                                                      <option value="2">Denied
                                                      </option>
                                                      <option value="3">Blocked
                                                      </option>
                                                      <option value="4">Removed
                                                      </option>
                                                    </select>
                                                  </div>
                                                </div>

                                                <div class="col-md-2">
                                                  <input class="searchbox-ov" type="search" placeholder="Search">

                                                </div>
                                              </form>
                                            </div>  
                                            <!-- relesae request table -->
                                            <div class="table-responsive">
                                              <table id="mytable" class="table table-bordred table-striped">
                                                <thead>
                                                  <tr>
                                                    <th>
                                                      <input type="checkbox" id="checkall" />
                                                    </th>
                                                    <th>No</th>
                                                    <th>Job Title</th>
                                                    <th>Job ID</th>
                                                    <th>Company Name</th>
                                                    <th>Amount Total</th>
                                                    <th>Ready Paid</th>
                                                    <th>Released</th>
                                                    <th>Status</th>
                                                    <!-- <th>option</th> -->
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>01</td>
                                                    <td>01.07.2017</td>
                                                    <td>Job</td>
                                                    <td>Repaire mobile</td>
                                                    <td>1000,-€</td>
                                                    <td>1000,-€</td>
                                                    <td>100,00 €</td>
                                                    <td><label class="label label-info" data-toggle="modal" data-target="#viewReleasePaymentModal">Open</label></td>
                                                          <!-- <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                  <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewReleasePaymentModal" >
                                                                      <span class="fa fa-eye">
                                                                      </span>
                                                                  </button>
                                                              </p>
                                                            </td> -->
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>02
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td><label class="label label-success" data-toggle="modal" data-target="#viewReleasePaymentModal">Done</label></td>
                                                          <!-- <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                  <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewReleasePaymentModal" >
                                                                      <span class="fa fa-eye">
                                                                      </span>
                                                                  </button>
                                                              </p>
                                                            </td> -->
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>03
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td><label class="label label-danger" data-toggle="modal" data-target="#deniedReleasePaymentModal">Denied</label>
                                                            </td>
                                                          <!-- <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                  <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#deniedReleasePaymentModal" >
                                                                      <span class="fa fa-eye">
                                                                      </span>
                                                                  </button>
                                                              </p>
                                                            </td> -->
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>04
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td><label class="label label-danger" data-toggle="modal" data-target="#deniedReleasePaymentModal">Denied</label>
                                                            </td>
                                                          <!-- <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                  <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#deniedReleasePaymentModal" >
                                                                      <span class="fa fa-eye">
                                                                      </span>
                                                                  </button>
                                                              </p>
                                                            </td> -->
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>05
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td><label class="label label-danger" data-toggle="modal" data-target="#deniedReleasePaymentModal">Denied</label>
                                                            </td>
                                                          <!-- <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                  <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#deniedReleasePaymentModal" >
                                                                      <span class="fa fa-eye">
                                                                      </span>
                                                                  </button>
                                                              </p>
                                                            </td> -->
                                                          </tr>

                                                        </tbody>
                                                      </table>
                                                      <div class="clearfix">
                                                      </div>
                                                      <ul class="pagination pull-right">
                                                        <li class="disabled">
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-left">
                                                            </span>
                                                          </a>
                                                        </li>
                                                        <li class="active">
                                                          <a href="#">1
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">2
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">3
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">4
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">5
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-right">
                                                            </span>
                                                          </a>
                                                        </li>
                                                      </ul>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Mohsin">
                                                      </div>
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Irshad">
                                                      </div>
                                                      <div class="form-group">
                                                        <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
                                                        </textarea>
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Update
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>
                                              <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Delete this entry
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="alert alert-danger">
                                                        <span class="glyphicon glyphicon-warning-sign">
                                                        </span> Are you sure you want to delete this Record?
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-success" >
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Yes
                                                      </button>
                                                      <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        <span class="glyphicon glyphicon-remove">
                                                        </span> No
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>

                                            </div>
                                          </div>
                                        </div>
                                        <!--tab-pane end -->
                                      </div>
                                      <!-- tab-content end -->
                                    </div>
                                    <!-- Projects List col-md-10 end -->
                                  </div>
                                  <!-- row end -->
                                </div>
                                <div class="clearfix">
                                </div>
                                <br>
                              </div>
                              <div role="tabpanel" class="tab-pane m-t-35" id="MyPaymentsAreaAboutUs" style="background: #eeeeee;margin-top:50px;">
                                <div class="row pdng10-0 searchBar" style="border-bottom: 1px solid #eeeeee;">
                                  <div class="col-md-12">

                                    <div class="col-lg-4" style="    margin-top: 12px;" >
                                      <div class="pamentstats3" style="background-color:white;">
                                        <h2 class="text-center2 paymenfont2">New Release Request</h2>
                                        <hr class="pauruler2">
                                        <h2 class="text-center2">10</h2>
                                      </div>

                                    </div>
                                    <div class="col-lg-4" style="    margin-top: 12px;" >
                                      <div class="pamentstats3" style="background-color:white;">
                                        <h2 class="text-center2 paymenfont2">Accepted Release Request</h2>
                                        <hr class="pauruler2">
                                        <h2 class="text-center2">2</h2>
                                      </div>
                                    </div>
                                    <div class="col-lg-4" style="    margin-top: 12px;">
                                      <div class="pamentstats3" style="background-color:white;">
                                        <h2 class="text-center2 paymenfont2">Denied Release Request</h2>
                                        <hr class="pauruler2">
                                        <h2 class="text-center2">8</h2>
                                      </div>
                                    </div>

                                  </div>
                                </div>
                                <!--second section-->
                                <div class="vd_content-section clearfix"  style="margin-top: -11px; border-top: 1px solid #eeeeee;">
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="tab-content no-bd mrgn0 pdng0">
                                        <div class="tab-pane active fade in" id="category1">
                                          <div class="panel widget container-fluid" style="background: #eee;">
                                            <div class="row mrgn30-0 projectRow" style=" background: #eeeeee;">
                                              <div class="container">
                                                <div class="row">
                                                  <div class="col-md-12" style="margin-top: 26px;">
                                                    <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0; border-bottom: 1px solid #eeeeee;">
                                                      <form>
                                                        <div class="col-md-2 col-md-offset-2">

                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>                                                               </select>
                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>
                                                        </div>

                                                        <div class="col-md-2">
                                                          <input class="searchbox-ov" type="search" placeholder="Search">
                                                        </div>
                                                      </form>
                                                    </div>  
                                                    <div class="table-responsive refund-request-payment">
                                                      <table id="mytable" class="table table-bordred table-striped">
                                                        <thead>
                                                          <tr>
                                                            <th>
                                                              <input type="checkbox" id="checkall" />
                                                            </th>
                                                            <th>No</th>
                                                            <th>Job Title</th>
                                                            <th>Job ID</th>
                                                            <th>Company Name</th>
                                                            <th>Amount Total</th>
                                                            <th>Ready Paid</th>
                                                            <th>Released</th>
                                                            <th>Status</th>
                                                            <th>option</th>
                                                          </tr>
                                                        </thead>
                                                        <tbody>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>01</td>
                                                            <td>01.07.2017</td>
                                                            <td>Job</td>
                                                            <td>Repaire mobile</td>
                                                            <td>1000,-€</td>
                                                            <td>1000,-€</td>
                                                            <td>100,00 €</td>
                                                            <td>Open</td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewOpenRefundPaymentModal" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>02
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Done
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>03
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Denied
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewDeniedRefundPaymentModal" >

                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>04
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Denied
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewDeniedRefundPaymentModal" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>05
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Denied
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#viewDeniedRefundPaymentModal" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>

                                                        </tbody>
                                                      </table>
                                                      <div class="clearfix">
                                                      </div>
                                                      <ul class="pagination pull-right">
                                                        <li class="disabled">
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-left">
                                                            </span>
                                                          </a>
                                                        </li>
                                                        <li class="active">
                                                          <a href="#">1
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">2
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">3
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">4
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">5
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-right">
                                                            </span>
                                                          </a>
                                                        </li>
                                                      </ul>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Mohsin">
                                                      </div>
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Irshad">
                                                      </div>
                                                      <div class="form-group">
                                                        <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
                                                        </textarea>
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Update
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>
                                              <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Delete this entry
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="alert alert-danger">
                                                        <span class="glyphicon glyphicon-warning-sign">
                                                        </span> Are you sure you want to delete this Record?
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-success" >
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Yes
                                                      </button>
                                                      <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        <span class="glyphicon glyphicon-remove">
                                                        </span> No
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>

                                            </div>
                                          </div>
                                        </div>
                                        <!--tab-pane end -->
                                      </div>
                                      <!-- tab-content end -->
                                    </div>
                                    <!-- Projects List col-md-10 end -->
                                  </div>
                                  <!-- row end -->
                                </div>
                                <div class="clearfix">
                                </div>
                                <br>
                              </div>
                              <div role="tabpanel" class="tab-pane m-t-35" id="MyPaymentsAreaOurTeam" style="background: #eeeeee;margin-top:50px;">

                                <!--second section-->
                                <div class="vd_content-section clearfix" style="margin-top: -11px; border-top: 1px solid #eeeeee;">
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="tab-content no-bd mrgn0 pdng0">
                                        <div class="tab-pane active fade in" id="category1">
                                          <div class="panel widget container-fluid" style="background: #eee;">
                                            <div class="row mrgn30-0 projectRow" style=" background: #eeeeee;">
                                              <div class="">
                                                <div class="row">
                                                  <div class="col-md-12" style="margin-top: 26px;">
                                                    <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0; border-bottom: 1px solid #eeeeee;">
                                                      <form>
                                                        <div class="col-md-2 col-md-offset-2">

                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>                                                               </select>

                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>
                                                        </div>

                                                        <div class="col-md-2">
                                                          <input class="searchbox-ov" type="search" placeholder="Search">

                                                        </div>
                                                      </form>
                                                    </div>  
                                                    <div class="table-responsive">
                                                      <table id="mytable" class="table table-bordred table-striped payout-payment">
                                                        <thead>
                                                          <tr>
                                                            <th>
                                                              <input type="checkbox" id="checkall">
                                                            </th>
                                                            <th>No</th>
                                                            <th>Job Title</th>
                                                            <th>Job ID</th>
                                                            <th>Company Name</th>
                                                            <th>Amount Total</th>
                                                            <th>Ready Paid</th>
                                                            <th>Released</th>
                                                            <th>Status</th>
                                                            <th>option</th>
                                                          </tr>
                                                        </thead>
                                                        <tbody>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis">
                                                            </td>
                                                            <td>01</td>
                                                            <td>01.07.2017</td>
                                                            <td>Job</td>
                                                            <td>Repaire mobile</td>
                                                            <td>1000,-€</td>
                                                            <td>1000,-€</td>
                                                            <td>100,00 €</td>
                                                            <td>Paid</td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="" data-original-title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#">
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis">
                                                            </td>
                                                            <td>02
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Paid
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="" data-original-title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#">
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis">
                                                            </td>
                                                            <td>03
                                                            </td>
                                                            <td>01.07.2017
                                                            </td>
                                                            <td>Job
                                                            </td>
                                                            <td>Repaire mobile
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>1000,-€
                                                            </td>
                                                            <td>100,00 €
                                                            </td>
                                                            <td>Open
                                                            </td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="" data-original-title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#openPayoutPaymentModal">
                                                                  
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          

                                                        </tbody>
                                                      </table>
                                                      <div class="clearfix">
                                                      </div>
                                                      <ul class="pagination pull-right">
                                                        <li class="disabled">
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-left">
                                                            </span>
                                                          </a>
                                                        </li>
                                                        <li class="active">
                                                          <a href="#">1
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">2
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">3
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">4
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">5
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-right">
                                                            </span>
                                                          </a>
                                                        </li>
                                                      </ul>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Mohsin">
                                                      </div>
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Irshad">
                                                      </div>
                                                      <div class="form-group">
                                                        <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
                                                        </textarea>
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Update
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>
                                              <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Delete this entry
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="alert alert-danger">
                                                        <span class="glyphicon glyphicon-warning-sign">
                                                        </span> Are you sure you want to delete this Record?
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-success" >
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Yes
                                                      </button>
                                                      <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        <span class="glyphicon glyphicon-remove">
                                                        </span> No
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>

                                            </div>
                                          </div>
                                        </div>
                                        <!--tab-pane end -->
                                      </div>
                                      <!-- tab-content end -->
                                    </div>
                                    <!-- Projects List col-md-10 end -->
                                  </div>
                                  <!-- row end -->
                                </div>
                                <div class="clearfix">
                                </div>
                                <br>
                              </div>
                              <div role="tabpanel" class="tab-pane m-t-35" id="MyPaymentsAreaMyPay" style="background: #eeeeee;margin-top:50px;">

                                <!--my invoice last part section-->
                                <div class="vd_content-section clearfix"  style="margin-top: -11px; border-top: 1px solid #eeeeee;">
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="tab-content no-bd mrgn0 pdng0">
                                        <div class="tab-pane active fade in" id="category1">
                                          <div class="panel widget container-fluid" style="background: #eee;">
                                            <div class="row mrgn30-0 projectRow" style=" background: #eeeeee;">
                                              <div class="">
                                                <div class="row" >
                                                  <div class="col-md-12" style="margin-top: 26px;">
                                                    <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0; border-bottom: 1px solid #eeeeee;">
                                                      <form>
                                                        <div class="col-md-2 col-md-offset-2">

                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>                                                               </select>

                                                        </div>
                                                        <div class="col-md-2">
                                                          <div>
                                                            <select>
                                                              <option value="" disabled="" selected="">Status
                                                              </option>
                                                              <option value="1">On Hold
                                                              </option>
                                                              <option value="2">Denied
                                                              </option>
                                                              <option value="3">Blocked
                                                              </option>
                                                              <option value="4">Removed
                                                              </option>
                                                            </select>
                                                          </div>
                                                        </div>

                                                        <div class="col-md-2">
                                                          <input class="searchbox-ov" type="search" placeholder="Search">

                                                        </div>
                                                      </form>
                                                    </div>  
                                                    <div class="table-responsive">
                                                      <table id="mytable" class="table table-bordred table-striped">
                                                        <thead>
                                                          <tr>
                                                            <th>
                                                              <input type="checkbox" id="checkall" />
                                                            </th>
                                                            <th>No </th>
                                                            <th>Invoice ID</th>
                                                            <th>Payment For</th>
                                                            <th>To Company</th>
                                                            <th>Amount</th>
                                                            <th>Date</th>
                                                            <th>Option</th>
                                                          </tr>
                                                        </thead>

                                                        <tbody>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>01</td>
                                                            <td>123HI</td>
                                                            <td>Job</td>
                                                            <td>Repair Mobile</td>
                                                            <td>1000,-€</td>
                                                            <td>01.07.2017</td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>02</td>
                                                            <td>123HI</td>
                                                            <td>Job</td>
                                                            <td>Repair Mobile</td>
                                                            <td>1000,-€</td>
                                                            <td>01.07.2017</td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>
                                                          <tr>
                                                            <td>
                                                              <input type="checkbox" class="checkthis" />
                                                            </td>
                                                            <td>03</td>
                                                            <td>123HI</td>
                                                            <td>Job</td>
                                                            <td>Repair Mobile</td>
                                                            <td>1000,-€</td>
                                                            <td>01.07.2017</td>
                                                            <td>
                                                              <p data-placement="top" data-toggle="tooltip" title="View">
                                                                <button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#" >
                                                                  <span class="fa fa-eye">
                                                                  </span>
                                                                </button>
                                                              </p>
                                                            </td>
                                                          </tr>

                                                        </tbody>
                                                      </table>
                                                      <div class="clearfix">
                                                      </div>
                                                      <ul class="pagination pull-right">
                                                        <li class="disabled">
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-left">
                                                            </span>
                                                          </a>
                                                        </li>
                                                        <li class="active">
                                                          <a href="#">1
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">2
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">3
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">4
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">5
                                                          </a>
                                                        </li>
                                                        <li>
                                                          <a href="#">
                                                            <span class="glyphicon glyphicon-chevron-right">
                                                            </span>
                                                          </a>
                                                        </li>
                                                      </ul>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Mohsin">
                                                      </div>
                                                      <div class="form-group">
                                                        <input class="form-control " type="text" placeholder="Irshad">
                                                      </div>
                                                      <div class="form-group">
                                                        <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
                                                        </textarea>
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Update
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>
                                              <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                        <span class="glyphicon glyphicon-remove" aria-hidden="true">
                                                        </span>
                                                      </button>
                                                      <h4 class="modal-title custom_align" id="Heading">Delete this entry
                                                      </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                      <div class="alert alert-danger">
                                                        <span class="glyphicon glyphicon-warning-sign">
                                                        </span> Are you sure you want to delete this Record?
                                                      </div>
                                                    </div>
                                                    <div class="modal-footer ">
                                                      <button type="button" class="btn btn-success" >
                                                        <span class="glyphicon glyphicon-ok-sign">
                                                        </span> Yes
                                                      </button>
                                                      <button type="button" class="btn btn-default" data-dismiss="modal">
                                                        <span class="glyphicon glyphicon-remove">
                                                        </span> No
                                                      </button>
                                                    </div>
                                                  </div>
                                                  <!-- /.modal-content --> 
                                                </div>
                                                <!-- /.modal-dialog --> 
                                              </div>

                                            </div>
                                          </div>
                                        </div>
                                        <!--tab-pane end -->
                                      </div>
                                      <!-- tab-content end -->
                                    </div>
                                    <!-- Projects List col-md-10 end -->
                                  </div>
                                  <!-- row end -->
                                </div>
                                <div class="clearfix">
                                </div>
                                <br>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix">
            </div>
            <br />
          </div>
<!-- /Center -->