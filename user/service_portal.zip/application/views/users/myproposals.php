<div class="rightSection">
  <!-- Header -->

  <div class="col-md-12 col-sm-12 col-xs-12 pull-left no-padding hederLogoSec">
    <div class="header-bottom-user">
      <div class="wrapper">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12">

            </div>
            <div class="col-lg-9 col-md-9 col-sm-12">
              <div class="nav" id="nav">
                <a href="index.html#" id="toggle">
                  <i class="fa fa-bars">
                  </i>
                </a>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- /Header -->

  <!-- /Header -->
  <div role="tabpanel" class="tab-pane " id="MyPostsArea">
    <div class="border-box">
      <div class=" custom-page-content">

      </div>
      <div style="background-color: #f3f3f3;" class="main-content">
        <div class="tab-section">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab-container" style="margin-top:0px;">
              <div class=" bhoechie-tab">
                <div class="bhoechie-tab-content">
                  <div>

                    <nav class="navbar navbar-default new-opp-top-nav nc-menu">
                      <div class="container top-menu-container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-3" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-3">
                          <ul class="nav navbar-nav">
                            <li class="active" role="presentation">
                              <a  href="index.html#MyPostsAreaInCheck" aria-controls="MyPostsAreaInCheck" role="tab" data-toggle="tab">
                              <i class="fa fa-bullhorn" aria-hidden="true"></i> All&nbsp;Proposals
                                  
                              </a>
                            </li>
                            <li class='white' role="presentation">
                              <a href="index.html#MyPostsAreaInHold" aria-controls="MyPostsAreaInHold" role="tab" data-toggle="tab">
                              <i class="fa fa-thumbs-o-down" aria-hidden="true"></i> Projects&nbsp;Faild
                                  
                              </a>
                            </li>
                            <li class="white" role="presentation">
                              <a  href="index.html#MyPostsAreaCancelled" aria-controls="MyPostsAreaCancelled" role="tab" data-toggle="tab">
                              <i class="fa fa-ban" aria-hidden="true"></i> Projects&nbsp;Canceled
                                 
                              </a>
                            </li>
                          </ul>
                        </div><!-- /.navbar-collapse -->

                      </div><!-- /.container-fluid -->
                    </nav>

                    <div class="tab-content no-t-m">
                      <div role="tabpanel" class="tab-pane active m-t-35" id="MyPostsAreaInCheck">
                        <!--second section-->
                        <div class="vd_content-section clearfix">
                          <div class="row">
                            <div style="margin-bottom: -89px;" class="col-md-12">
                              <div class="tab-content no-bd mrgn0 pdng0">
                                <div class="tab-pane active fade in" id="category1">
                                  <!-- My post -->
                                  <div class="panel widget container-fluid">
                                    <div class="row mrgn30-0 projectRow">
                                      <a href="javascript:void(0);" data-toggle="modal" data-target="#modalit1" title=""
                                      class="notice notice-success" style="color: black;">

                                      <div class="col-sm-3 brdRight">

                                        <h4>Project Title</h4>
                                        <p style="color: black;">12-02-2017 /17:30 Uhr</p>

                                      </div>
                                      <div class="col-sm-2 brdRight text-align">
                                        <h4>Budget
                                        </h4>
                                        <h4 class="text-height">2500,-&euro; Fix
                                        </h4>
                                      </div>
                                      <div class="col-sm-2 brdRight text-align">
                                        <h4>Total Task
                                        </h4>
                                        <h4 class="text-height">4
                                        </h4>
                                      </div>
                                      <div class="col-sm-2 brdRight text-align">
                                        <h4>Personals
                                        </h4>
                                        <h4 class="text-height" style="color: red;">24
                                        </h4>
                                      </div>
                                      <div class="col-sm-3 text-align">
                                        <h4>Proposals
                                        </h4>
                                        <h4 class="text-height">
                                          <button type="button" class="btn btn-primary btn-sm" style="width: 39%"><i class="fa fa-eye" aria-hidden="true"></i>View</button></h4>
                                        </div>

                                      </a>
                                    </div>


                                  </div>
                                </div>
                                <!--tab-pane end -->
                              </div>
                              <!-- tab-content end -->
                            </div>
                            <!-- Projects List col-md-10 end -->
                          </div>
                          <!-- row end -->
                        </div>
                        <div class="clearfix">
                        </div>
                        <br>
                      </div>
                      <div role="tabpanel" class="tab-pane m-t-35" id="MyPostsAreaInHold">

                        <!--second section-->
                        <div class="vd_content-section clearfix">
                          <div class="row">
                            <div  style="margin-bottom: -89px;" class="col-md-12">
                              <div class="tab-content no-bd mrgn0 pdng0">
                                <div class="tab-pane active fade in" id="category1">

                                  <div class="panel widget container-fluid">
                                    <div class="row mrgn30-0 projectRow">
                                      <a href="javascript:void(0);" data-toggle="modal" data-target="#viewThisJob" title=""
                                      class="notice notice-success" style="color: black;">

                                      <div class="col-sm-3 brdRight" data-toggle="modal" data-target="#propasalFailedOptionModal">

                                        <h4>Project Title</h4>
                                        <p style="color: black;">12-02-2017 / 17:30 Uhr</p>

                                      </div>
                                      <div class="col-sm-3 brdRight text-align" data-toggle="modal" data-target="#propasalFailedOptionModal">
                                        <h4>Budget
                                        </h4>
                                        <h4 class="text-height">15,-â‚¬ Hourly
                                        </h4>
                                      </div>
                                      <div class="col-sm-3 brdRight text-align" data-toggle="modal" data-target="#propasalFailedOptionModal">
                                        <h4>Total Task
                                        </h4>
                                        <h4 class="text-height">4
                                        </h4>
                                      </div>
                                      <div class="col-sm-3 text-align" data-toggle="modal" data-target="#propasalFailedOptionModal">
                                        <h4>Proposals
                                        </h4>
                                        <h4 class="text-height" style="color: red;">
                                        0</h4>
                                      </div>

                                    </a>
                                  </div>
                                </div>
                              </div>
                              <!--tab-pane end -->
                            </div>
                            <!-- tab-content end -->
                          </div>
                          <!-- Projects List col-md-10 end -->
                        </div>
                        <!-- row end -->
                      </div>
                      <div class="clearfix">
                      </div>
                      <br>
                    </div>
                    <div role="tabpanel" class="tab-pane m-t-35" id="MyPostsAreaCancelled">

                      <!--second section-->
                      <div class="vd_content-section clearfix">
                        <div class="row">
                          <div  style="margin-bottom: -89px;" class="col-md-12">
                            <div class="tab-content no-bd mrgn0 pdng0">
                              <div class="tab-pane active fade in" id="category1">
                                <!-- my -->
                                <div class="panel widget container-fluid">
                                  <div class="row mrgn30-0 projectRow">
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#viewThisJob" title=""
                                    class="notice notice-success" style="color: black;">

                                    <div class="col-sm-3 brdRight">

                                      <h4>Project Title</h4>
                                      <p style="color: black;">12-02-2017 / 17:30 Uhr</p>

                                    </div>
                                    <div class="col-sm-3 brdRight text-align" data-toggle="modal" data-target="#projectCancelOptionsModal">
                                      <h4>Budget
                                      </h4>
                                      <h4 class="text-height">Agreement
                                      </h4>
                                    </div>
                                    <div class="col-sm-3 brdRight text-align" data-toggle="modal" data-target="#projectCancelOptionsModal">
                                      <h4>Total Task
                                      </h4>
                                      <h4 class="text-height">4
                                      </h4>
                                    </div>
                                    <div class="col-sm-3 text-align" data-toggle="modal" data-target="#projectCancelOptionsModal">
                                      <h4>Proposals
                                      </h4>
                                      <h4 class="text-height" style="color: red;">
                                      12</h4>
                                    </div>

                                  </a>
                                </div>
                              </div>
                            </div>
                            <!--tab-pane end -->
                          </div>
                          <!-- tab-content end -->
                        </div>
                        <!-- Projects List col-md-10 end -->
                      </div>
                      <!-- row end -->
                    </div>
                    <div class="clearfix">
                    </div>
                    <br>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="clearfix">
</div>
<br />
</div>