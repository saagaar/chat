<div class="rightSection">
  <!-- Header -->

  <div class="col-md-12 col-sm-12 col-xs-12 pull-left no-padding hederLogoSec">
    <div class="header-bottom-user">
      <div class="wrapper">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12">

            </div>
            <div class="col-lg-9 col-md-9 col-sm-12">
              <div class="nav" id="nav">
                <a href="index.html#" id="toggle">
                  <i class="fa fa-bars">
                  </i>
                </a>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- /Header -->
  <!-- Center -->
  <div role="tabpanel" class="tab-pane " id="MyWarrantyArea">
    <div class="border-box">
      <div class=" custom-page-content">

      </div>
      <!--  My Warranty table -->
      <div class="main-content">
        <div class="tab-section">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab-container" style="background: #eee;margin-top:0px;">
              <div class=" bhoechie-tab">
                <div class="bhoechie-tab-content">
                  <div>

                    <nav class="navbar navbar-default new-opp-top-nav nc-menu">
                      <div class="container top-menu-container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-3" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-3">
                          <ul class="nav navbar-nav">
                            <li class="active" role="presentation">
                                <a href="index.html#MyWarrantyAreaSettings" MyContractsAreaCurrentContracts-controls="MyWarrantyAreaSettings" role="tab" data-toggle="tab">
                                    <i class="fa fa-briefcase" aria-hidden="true">
                                            </i> Work Waranty
                                    
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="index.html#MyWarrantyAreaOurFollower" MyContractsAreaCurrentContracts-controls="MyWarrantyAreaOurFollower" role="tab" data-toggle="tab">
                                   <i class="fa fa-percent" aria-hidden="true">
                                            </i> Services Waranty
                                   
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="index.html#MyWarrantyAreaAboutUs" MyContractsAreaCurrentContracts-controls="MyWarrantyAreaAboutUs" role="tab" data-toggle="tab">
                                    <i class="fa fa-heart-o" aria-hidden="true">
                                            </i> Items Waranty
                                </a>
                            </li>
                          </ul>
                        </div><!-- /.navbar-collapse -->

                      </div><!-- /.container-fluid -->
                    </nav>

                    <div class="tab-content no-t-m">
                      <div role="tabpanel" class="tab-pane m-t-35 active" id="MyWarrantyAreaSettings">

                        <!--second section-->
                        <div class="vd_content-section clearfix" style=" border-top: 1px solid #eee;">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="tab-content no-bd mrgn0 pdng0">
                                <div class="tab-pane active fade in" id="category1">
                                  <div class="" style="background: #eee;">
                                    <div class="row ">
                                      <div class="container">
                                        <div class="row" style="background: #eee;">
                                          <div class="col-md-12" style="background: #eee; border-bottom: 2px solid #eee;">

                                            <div class="table-responsive">
                                              <table id="mytable" class="table table-bordred table-striped warrentytable">
                                                <thead>
                                                  <th>
                                                    <input type="checkbox" id="checkall" />
                                                  </th>
                                                  <th>No</th>
                                                  <th>Title</th>
                                                  <th>Company Name</th>
                                                  <th>Work Time</th>
                                                  <th>Delivery Time</th>
                                                  <th>Warranty</th>
                                                  <th>Status</th>
                                                  <!-- <th>Option</th> -->
                                                </thead>
                                                <tbody>
                                                  <tr>
                                                    <td>
                                                      <input type="checkbox" class="checkthis" />
                                                    </td>
                                                    <td>01
                                                    </td>
                                                    <td>01.07.2017
                                                    </td>
                                                    <td>
                                                    </td>
                                                    <td>
                                                    </td>
                                                    <td>
                                                    </td>
                                                    <td>
                                                    </td>
                                                    <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->

</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>02
  </td>
  <td>01.07.2017
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td><label class="label label-danger" data-toggle="modal" data-target="#expiredWarrentyModal">Expired</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#expiredWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>03
  </td>
  <td>01.07.2017
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>04
  </td>
  <td>01.07.2017
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>05
  </td>
  <td>01.07.2017
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td>
  </td>
  <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>

</tbody>
</table>
<div class="clearfix">
</div>
<ul class="pagination pull-right">
  <li class="disabled">
    <a href="#">
      <span class="glyphicon glyphicon-chevron-left">
      </span>
    </a>
  </li>
  <li class="active">
    <a href="#">1
    </a>
  </li>
  <li>
    <a href="#">2
    </a>
  </li>
  <li>
    <a href="#">3
    </a>
  </li>
  <li>
    <a href="#">4
    </a>
  </li>
  <li>
    <a href="#">5
    </a>
  </li>
  <li>
    <a href="#">
      <span class="glyphicon glyphicon-chevron-right">
      </span>
    </a>
  </li>
</ul>
</div>
</div>
</div>
</div>
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          <span class="glyphicon glyphicon-remove" aria-hidden="true">
          </span>
        </button>
        <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
        </h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <input class="form-control " type="text" placeholder="Mohsin">
        </div>
        <div class="form-group">
          <input class="form-control " type="text" placeholder="Irshad">
        </div>
        <div class="form-group">
          <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
          </textarea>
        </div>
      </div>
      <div class="modal-footer ">
        <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
          <span class="glyphicon glyphicon-ok-sign">
          </span> Update
        </button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          <span class="glyphicon glyphicon-remove" aria-hidden="true">
          </span>
        </button>
        <h4 class="modal-title custom_align" id="Heading">Delete this entry
        </h4>
      </div>
      <div class="modal-body">
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-warning-sign">
          </span> Are you sure you want to delete this Record?
        </div>
      </div>
      <div class="modal-footer ">
        <button type="button" class="btn btn-success" >
          <span class="glyphicon glyphicon-ok-sign">
          </span> Yes
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span class="glyphicon glyphicon-remove">
          </span> No
        </button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>

</div>
</div>
</div>
<!--tab-pane end -->
</div>
<!-- tab-content end -->
</div>
<!-- Projects List col-md-10 end -->
</div>
<!-- row end -->
</div>
<div class="clearfix">
</div>
<br>
</div>
<div role="tabpanel" class="tab-pane m-t-35" id="MyWarrantyAreaOurFollower" style="margin-bottom: 15px;">

  <!--second section-->
  <div class="vd_content-section clearfix no-t-m" style=" border-top: 1px solid #eee;">
    <div class="row">
      <div class="col-md-12">
        <div class="tab-content no-bd mrgn0 pdng0">
          <div class="tab-pane active fade in" id="category1">
            <div class="panel widget container-fluid" style="background: #eee;">
              <div class="row">
                <div class="container">
                  <div class="row">
                    <div class="col-md-12">
<!-- <div class="row pdng10-0 searchBar" style="background: white; width: 100%;margin: 0;">
<form>
<div class="col-md-2 col-md-offset-2">
<div>
<span role="status" aria-live="polite" class="ui-helper-hidden-accessible">
</span>
<input class="ui-autocomplete-input" type="text" placeholder="Contract ID" id="project-autocomplete" autocomplete="off">
</div>
</div>
<div class="col-md-2">
<div>
<span role="status" aria-live="polite" class="ui-helper-hidden-accessible">
</span>
<input class="ui-autocomplete-input" type="text" placeholder="User Name" id="company-autocomplete" autocomplete="off">
</div>
</div>
<div class="col-md-2">
<div>
<select>
<option value="" disabled="" selected="">Status
</option>
<option value="1">On Hold
</option>
<option value="2">Denied
</option>
<option value="3">Blocked
</option>
<option value="4">Removed
</option>
</select>
</div>
</div>
<div class="col-md-2">
<button type="button" class="btn vd_btn vd_bg-blue" data-toggle="modal" data-target="" style="max-height:32px;color: white;">
<span class="append-icon">
<i class="fa fa-search fa-fw">
</i>
</span>Search Projects
</button>
</div>
</form>

</div> -->  
<div class="table-responsive" style="margin-bottom: -57px;">
  <table id="mytable" class="table table-bordred table-striped">
    <thead>
      <th>
        <input type="checkbox" id="checkall" />
      </th>
      <th>No 
      </th>
      <th>Title
      </th>
      <th>Company Name
      </th>
      <th>Work Time
      </th>
      <th>Delivery Time
      </th>
      <th>Warranty
      </th>
      <th>Status
      </th>

<!--   <th>Option
</th> -->
</thead>
<tbody>
  <tr>
    <td>
      <input type="checkbox" class="checkthis" />
    </td>
    <td>01
    </td>
    <td>01.07.2017
    </td>
    <td>Job
    </td>
    <td>Repaire mobile
    </td>
    <td>1000,-€
    </td>
    <td>1000,-€
    </td>
    <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>02
  </td>
  <td>01.07.2017
  </td>
  <td>Job
  </td>
  <td>Repaire mobile
  </td>
  <td>1000,-€
  </td>
  <td>1000,-€
  </td>
  <td><label class="label label-danger" data-toggle="modal" data-target="#expiredWarrentyModal">Expired</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#expiredWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>03
  </td>
  <td>01.07.2017
  </td>
  <td>Job
  </td>
  <td>Repaire mobile
  </td>
  <td>1000,-€
  </td>
  <td>1000,-€
  </td>
  <td><label class="label label-danger" data-toggle="modal" data-target="#expiredWarrentyModal">Expired</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#expiredWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>04
  </td>
  <td>01.07.2017
  </td>
  <td>Job
  </td>
  <td>Repaire mobile
  </td>
  <td>1000,-€
  </td>
  <td>1000,-€
  </td>
  <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>
<tr>
  <td>
    <input type="checkbox" class="checkthis" />
  </td>
  <td>05
  </td>
  <td>01.07.2017
  </td>
  <td>Job
  </td>
  <td>Repaire mobile
  </td>
  <td>1000,-€
  </td>
  <td>1000,-€
  </td>
  <td><label class="label label-success" data-toggle="modal" data-target="#activeWarrentyModal">Active</label></td>

<!-- <td class="options">
<p data-placement="top" data-toggle="tooltip" title="View">
<button class="btn btn-primary btn-xs" data-title="View" data-toggle="modal" data-target="#activeWarrentyModal" >
<span class="glyphicon glyphicon-eye-open">
</span>
</button>
</p>
</td> -->
</tr>

</tbody>
</table>
<div class="clearfix">
</div>
<ul class="pagination pull-right">
  <li class="disabled">
    <a href="#">
      <span class="glyphicon glyphicon-chevron-left">
      </span>
    </a>
  </li>
  <li class="active">
    <a href="#">1
    </a>
  </li>
  <li>
    <a href="#">2
    </a>
  </li>
  <li>
    <a href="#">3
    </a>
  </li>
  <li>
    <a href="#">4
    </a>
  </li>
  <li>
    <a href="#">5
    </a>
  </li>
  <li>
    <a href="#">
      <span class="glyphicon glyphicon-chevron-right">
      </span>
    </a>
  </li>
</ul>
</div>
</div>
</div>
</div>
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          <span class="glyphicon glyphicon-remove" aria-hidden="true">
          </span>
        </button>
        <h4 class="modal-title custom_align" id="Heading">Edit Your Detail
        </h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <input class="form-control " type="text" placeholder="Mohsin">
        </div>
        <div class="form-group">
          <input class="form-control " type="text" placeholder="Irshad">
        </div>
        <div class="form-group">
          <textarea rows="2" class="form-control" placeholder="CB 106/107 Street # 11 Wah Cantt Islamabad Pakistan">
          </textarea>
        </div>
      </div>
      <div class="modal-footer ">
        <button type="button" class="btn btn-warning btn-lg" style="width: 100%;">
          <span class="glyphicon glyphicon-ok-sign">
          </span> Update
        </button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          <span class="glyphicon glyphicon-remove" aria-hidden="true">
          </span>
        </button>
        <h4 class="modal-title custom_align" id="Heading">Delete this entry
        </h4>
      </div>
      <div class="modal-body">
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-warning-sign">
          </span> Are you sure you want to delete this Record?
        </div>
      </div>
      <div class="modal-footer ">
        <button type="button" class="btn btn-success" >
          <span class="glyphicon glyphicon-ok-sign">
          </span> Yes
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span class="glyphicon glyphicon-remove">
          </span> No
        </button>
      </div>
    </div>
    <!-- /.modal-content --> 
  </div>
  <!-- /.modal-dialog --> 
</div>

</div>
</div>
</div>
<!--tab-pane end -->
</div>
<!-- tab-content end -->
</div>
<!-- Projects List col-md-10 end -->
</div>
<!-- row end -->
</div>
<div class="clearfix">
</div>
<br>
</div>
<div role="tabpanel" class="tab-pane m-t-35" id="MyWarrantyAreaAboutUs">

  <!--second section-->
  <div class="vd_content-section clearfix" style=" border-top: 1px solid #eee;">
    <div class="row">
      <div class="col-md-12" style="margin-bottom: -46px;">
        <div class="tab-content no-bd mrgn0 pdng0">
          <div class="tab-pane active fade in" id="category1">
            <div class="panel widget container-fluid" style="background: #eee;">
              <div class="row mrgn30-0 projectRow" style="background: #eee;">
                <a href="javascript:void(0);" data-toggle="modal" data-target="#viewThisJob" title="" class="notice notice-success" style="color: black;">

                  <div class="col-sm-12 text-align">


                    <h4>Comming soon</h4>


                  </div>                
                </a>
              </div>

            </div>
          </div>
          <!--tab-pane end -->
        </div>
        <!-- tab-content end -->
      </div>
      <!-- Projects List col-md-10 end -->
    </div>
    <!-- row end -->
  </div>
  <div class="clearfix">
  </div>
  <br>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearfix">
</div>
<br />
</div>
<!-- /Center -->